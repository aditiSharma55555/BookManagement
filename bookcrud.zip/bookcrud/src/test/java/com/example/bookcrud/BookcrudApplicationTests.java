package com.example.bookcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookcrudApplicationTests {

    @Test
    void contextLoads() {
    }

}
