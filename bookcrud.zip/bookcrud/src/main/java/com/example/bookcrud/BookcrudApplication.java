package com.example.bookcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookcrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookcrudApplication.class, args);
    }
}

